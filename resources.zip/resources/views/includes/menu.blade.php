<div class="mobile-menu-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="mobile-menu">
                    <nav id="dropdown">
                        <ul class="mobile-menu-nav">
                            @if(Auth::user()->user_type != 1)
                                <li><a  href="{{asset('/home')}}"><i class="fa fa-home"></i> Home</a>
                                </li>
                            @endif
                            @if(Auth::user()->user_type == 1001 || Auth::user()->user_type == 101 || Auth::user()->user_type == 2)
                                <li><a href="{{asset('/categories/showAll')}}"><i class="notika-icon notika-edit"></i> Categories</a>
                                </li>
                                @if(Auth::user()->user_type == 1001 || Auth::user()->user_type == 101)
                                    <li><a data-toggle="" href="{{asset('/recivingGoods')}}" ><i class="notika-icon notika-mail" ></i> Receiving Goods</a>
                                    </li>
                                    <li><a href="{{asset('/users/allUsers')}}"><i class="notika-icon notika-bar-chart"></i>Users </a>
                                    </li>
                                @endif
                            @endif
                            @if(Auth::user()->user_type != 2)
                                <li><a href="{{asset('requestedGoods/addRequest')}}"><i class="notika-icon notika-windows"></i> Add Request</a></li>
                                @if(Auth::user()->user_type == 1)
                                    <li><a  href="{{asset('requestedGoods/MyOrders')}}"><i class="notika-icon notika-windows"></i> My Orders</a></li>
                                @endif
                            @endif
                            @if(Auth::user()->user_type != 1)
                                <li><a href="{{asset('requestedGoods/PendingRequests')}}"><i class="notika-icon notika-windows"></i> Pending Request</a></li>
                            @endif
                            @if(Auth::user()->user_type == 1001 || Auth::user()->user_type == 101 || Auth::user()->user_type == 2)
                                <li><a data-toggle="tab" href="#Forms"><i class="notika-icon notika-form"></i> Reports</a>
                                    <ul class="notika-main-menu-dropdown">
                                        <li><a href="{{asset('reports/requestedItemsReports')}}">Requested Items</a>
                                        </li>
                                        <li><a href="{{asset('reports/recivingItemsReports')}}">Receiving Items</a>
                                        </li>
                                        <li><a href="{{asset('reports/inventoryList')}}">Inventory List</a>
                                        </li>
                                    </ul>
                                </li>
                            @endif
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Mobile Menu end -->
<!-- Main Menu area start-->
<div class="main-menu-area mg-tb-40">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <ul class="nav nav-tabs notika-menu-wrap menu-it-icon-pro">
                    @if(Auth::user()->user_type != 1)
                        <li><a  href="{{asset('/home')}}"><i class="fa fa-home"></i> Home</a>
                        </li>
                    @endif
                    @if(Auth::user()->user_type == 1001 || Auth::user()->user_type == 101 || Auth::user()->user_type == 2)
                        <li><a href="{{asset('/categories/showAll')}}"><i class="notika-icon notika-edit"></i> Categories</a>
                        </li>
                        @if(Auth::user()->user_type == 1001 || Auth::user()->user_type == 2)
                            <li><a href="{{asset('/users/allUsers')}}"><i class="notika-icon notika-bar-chart"></i>Users </a></li>
                        @endif
                        @if(Auth::user()->user_type == 1001 || Auth::user()->user_type == 101)
                            <li><a data-toggle="" href="{{asset('/recivingGoods')}}" ><i class="notika-icon notika-mail" ></i> Receiving Goods</a>
                            </li>
                        @endif
                    @endif
                    @if(Auth::user()->user_type != 2)
                        @if(Auth::user()->user_type == 1001 || Auth::user()->user_type != 101)
                            <li><a href="{{asset('requestedGoods/addRequest')}}"><i class="notika-icon notika-windows"></i> Add Request</a></li>
                        @endif
                        @if(Auth::user()->user_type == 1001 || Auth::user()->user_type == 1)
                            <li><a  href="{{asset('requestedGoods/MyOrders')}}"><i class="notika-icon notika-windows"></i> My Orders</a></li>
                            <li><a  href="{{asset('reports/inventoryList')}}"><i class="notika-icon notika-windows"></i> Inventory List</a></li>
                        @endif
                    @endif
                    @if(Auth::user()->user_type != 1)
                        <li><a href="{{asset('requestedGoods/PendingRequests')}}"><i class="notika-icon notika-windows"></i> Pending Request</a></li>
                    @endif
                    @if(Auth::user()->user_type == 1001 || Auth::user()->user_type == 101 || Auth::user()->user_type == 2)
                        <li>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="notika-icon notika-form"></i> Reports
                                <span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu main-menu-dropdown">
                                <li><a href="{{asset('reports/requestedItemsReports')}}">Requested Items</a></li>
                                <li><a href="{{asset('reports/recivingItems')}}">Receiving Items</a></li>
                                <li><a href="{{asset('reports/inventoryList')}}">Inventory List</a></li>
                            </ul>
                        </li>
                    @endif
                </ul>
            </div>
        </div>
    </div>
</div>
<div class="ajaxProgress">
    <h3>Please wait</h3>
    <img src="{{asset('img/ajax-loader.gif')}}">
</div>
<!-- Main Menu area End-->
