@extends('layouts.app')
@include('includes.header')
@include('includes.menu')
@section('content')
    <div class="breadcomb-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="breadcomb-list">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <div class="breadcomb-wp">
                                    <div class="breadcomb-icon">
                                        <i class="notika-icon notika-form"></i>
                                    </div>
                                    <div class="breadcomb-ctn" style="margin-top: 10px;">
                                        <h2>Add Request</h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <form action="{{asset('/requestedGoods/addRequestedGoods')}}" method="post" id="addRequest">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="form-example-wrap mg-t-30">
                                    <div class="form-example-int form-horizental">
                                        <div class="cmp-tb-hd cmp-int-hd">
                                            <h2>Select Goods</h2>
                                            <div class="breadcomb-report">
                                                <a onclick="addRow()" data-placement="left" title="Add Coloumn" class="btn waves-effect"><i class="notika-icon notika-plus-symbol"></i></a>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="row">
                                                <table class="table" id="recivingGoodsTable">
                                                    <tr>
                                                        <th>Category</th>
                                                        <th>Item</th>
                                                        <th>Model no</th>
                                                        <th>Brand Name</th>
                                                        <th>Avalible Quantity</th>
                                                        <th>Requested Qty</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <select class="form-control categories" name="categories[]" id="categories"  onchange="getCategoryItems(this)" >
                                                                <option value="">Select Category</option>
                                                                @foreach($categories as $k => $val)
                                                                    <option value="{{$val->id}}" {{isset($data->category_id) &&  $data->category_id == $val->id ? 'selected' : ''}}>{{$val->title}}</option>
                                                                @endforeach
                                                            </select>
                                                        </td>
                                                        <td>
                                                            <select class="form-control items" name="items[]" onchange="getItems(this)" disabled>
                                                                <option value="0">Select Item</option>
                                                            </select>
                                                        </td>
                                                        <td>
                                                            <label class="model_no">Model no</label>
                                                        </td>
                                                        <td>
                                                            <label class="brand_name">Brand Name</label>
                                                        </td>
                                                        <td>
                                                            <label class="avalible_qty">Avalible Quantity</label>
                                                        </td>
                                                        <td>
                                                            <input type="number" class="requested_qty form-control" style="width: 100px;" name="requested_qty[]" disabled required>
                                                        </td>
                                                        <td></td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <table>

                            <tr id="main_row" style="display:none;">
                                <td>
                                    <select class="form-control categories" name="categories[]" onchange="getCategoryItems(this)" >
                                        <option value="">Select Category</option>
                                        @foreach($categories as $k => $val)
                                            <option value="{{$val->id}}" {{isset($data->category_id) &&  $data->category_id == $val->id ? 'selected' : ''}}>{{$val->title}}</option>
                                        @endforeach
                                    </select>
                                </td>
                                <td>
                                    <select class="form-control items" name="items[]" onchange="getItems(this)" style="width: 150px" disabled required>
                                        <option value="0">Item</option>
                                    </select>
                                </td>
                                <td>
                                    <label class="model_no">Model no</label>
                                </td>
                                <td>
                                    <label class="brand_name">Brand Name</label>
                                </td>
                                <td>
                                    <label class="avalible_qty">Avalible Quantity</label>
                                </td>
                                <td>
                                    <input type="number" class="requested_qty form-control" style="width: 100px;" name="requested_qty[]" disabled required>
                                </td>
                                <td>
                                    <a onclick="remove_row(this)" title="Remove Coloumn" class="btn-danger notika-btn-danger btn waves-effect"><i class="notika-icon notika-trash"></i></a>
                                </td>

                            </tr>
                        </table>
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="form-example-wrap mg-t-30">
                                    <div class="form-example-int form-horizental">
                                        <div class="cmp-tb-hd cmp-int-hd">
                                            <h2>Add Details</h2>
                                        </div>
                                        <div class="form-group">
                                            {{csrf_field()}}
                                            <div class="form-example-int form-horizental">
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">
                                                            <label class="hrzn-fm ">Project Name</label>
                                                        </div>
                                                        <div class="col-lg-8 col-md-7 col-sm-7 col-xs-12">
                                                            <div class="nk-int-st">
                                                                <input type="text" name="project_name" class="form-control input-md" id="project_name" placeholder="Project Name" required>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-example-int mg-t-15">
                                                    <div class="row">
                                                        <div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">
                                                        </div>
                                                        <div class="col-lg-8 col-md-7 col-sm-7 col-xs-12">
                                                            <br>
                                                            <button  onclick="validateRequest()" class="btn btn-success notika-btn-success pull-right">Add Request</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                    {{--<div class="row">--}}
                        {{--<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">--}}
                            {{--<div class="form-example-wrap mg-t-30">--}}
                                {{--<form action="{{asset('requestedGoods/CategoryItemsDetails')}}" method="post">--}}
                                    {{--{{csrf_field()}}--}}
                                    {{--<div class="form-example-int form-horizental">--}}
                                        {{--<div class="form-group">--}}
                                            {{--<div class="row">--}}
                                                {{--<div class="col-lg-1 col-md-2 col-sm-2 col-xs-12">--}}
                                                {{--</div>--}}
                                                {{--<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">--}}
                                                    {{--<div class="nk-int-mk sl-dp-mn sm-res-mg-t-10">--}}
                                                        {{--<h2>Select Category</h2>--}}
                                                    {{--</div>--}}
                                                    {{--<select class="form-control" name="category" id="categories" onchange="getCategoryItems()">--}}
                                                        {{--<option>Select Category</option>--}}
                                                        {{--@foreach($categories as $k => $val)--}}
                                                            {{--<option value="{{$val->id}}" {{isset($data->category_id) &&  $data->category_id == $val->id ? 'selected' : ''}}>{{$val->title}}</option>--}}
                                                        {{--@endforeach--}}
                                                    {{--</select>--}}
                                                {{--</div>--}}
                                                {{--<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">--}}
                                                    {{--<div class="nk-int-mk sl-dp-mn sm-res-mg-t-10">--}}
                                                        {{--<h2 style="color: transparent;">Search</h2>--}}
                                                    {{--</div>--}}
                                                    {{--<div class="col-lg-8 col-md-7 col-sm-7 col-xs-12">--}}
                                                        {{--<button type="submit" class="btn btn-success notika-btn-success col-lg-12">Search </button>--}}
                                                    {{--</div>--}}
                                                {{--</div>--}}
                                            {{--</div>--}}
                                        {{--</div>--}}
                                    {{--</div>--}}
                                {{--</form>--}}
                            {{--</div>--}}
                        {{--</div>--}}
                    {{--</div>--}}
                {{--</div>--}}
            {{--</div>--}}
        {{--</div>--}}
    {{--</div>--}}
    {{--@if(isset($data))--}}
        {{--<div class="data-table-area">--}}
        {{--<div class="container">--}}
            {{--<div class="row">--}}
                {{--<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">--}}
                    {{--<div class="data-table-list">--}}
                        {{--<div class="basic-tb-hd">--}}
                            {{--<h2>Category Items</h2>--}}
                        {{--</div>--}}
                        {{--<div class="table-responsive">--}}
                            {{--<table id="data-table-basic" class="table table-hover">--}}
                                {{--<thead>--}}
                                {{--<tr>--}}
                                    {{--<th>#</th>--}}
                                    {{--<th>Description</th>--}}
                                    {{--<th>Model No</th>--}}
                                    {{--<th>Brand Name</th>--}}
                                    {{--<th>Avalible Quantity</th>--}}
                                    {{--<th>Actions</th>--}}
                                {{--</tr>--}}
                                {{--</thead>--}}
                                {{--<tbody>--}}
                                {{--@foreach($data as $k => $val)--}}
                                    {{--<tr>--}}
                                        {{--<td>{{$k+1}}</td>--}}
                                        {{--<td>{{$val->description}}</td>--}}
                                        {{--<td>{{$val->model_no}}</td>--}}
                                        {{--<td>{{$val->brand_name}}</td>--}}
                                        {{--<td style="color: indianred; font-weight: bold;">{{$val->quantity}}</td>--}}
                                        {{--<td>--}}
                                            {{--<div class="col-lg-12 col-md-12 col-sm-12  col-xs-12">--}}
                                                {{--<button onclick="showRequestModel({{$val->id }},'{{$val->description}}','{{$val->quantity}}')" class="btn btn-success notika-btn-success col-lg-12">Add Request </button>--}}
                                            {{--</div>--}}
                                        {{--</td>--}}
                                    {{--</tr>--}}
                                {{--@endforeach--}}
                                {{--</tbody>--}}
                                {{--<tfoot>--}}
                                {{--<tr>--}}
                                    {{--<th>#</th>--}}
                                    {{--<th>Description</th>--}}
                                    {{--<th>Model No</th>--}}
                                    {{--<th>Brand Name</th>--}}
                                    {{--<th>Avalible Quantity</th>--}}
                                    {{--<th>Actions</th>--}}
                                {{--</tr>--}}
                                {{--</tfoot>--}}
                            {{--</table>--}}
                        {{--</div>--}}
                    {{--</div>--}}
                {{--</div>--}}
            {{--</div>--}}
        {{--</div>--}}
    {{--</div>--}}
    {{--@endif--}}
    {{--<div class="modal fade" id="myModaltwo" role="dialog">--}}
        {{--<div class="modal-dialog modals-default">--}}
            {{--<div class="modal-content">--}}
                {{--<div class="modal-header">--}}
                    {{--<button type="button" class="close" data-dismiss="modal">&times;</button>--}}
                {{--</div>--}}
                {{--<form action="{{asset('requestedGoods/addRequestedGoods')}}" method="post" id="addRequestedGoods">--}}
                    {{--<div class="modal-body">--}}
                        {{--<h2 id="modal_title">Modal title</h2>--}}
                        {{--<br>--}}
                        {{--{{csrf_field()}}--}}
                        {{--<input type="hidden" id="item_id" name="item_id" value="">--}}
                        {{--<input type="hidden" id="quatity" name="quatity" value="">--}}
                        {{--<div class="form-example-int form-horizental">--}}
                            {{--<div class="form-group">--}}
                                {{--<div class="row">--}}
                                    {{--<div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">--}}
                                        {{--<label class="hrzn-fm ">Requested Quantity</label>--}}
                                    {{--</div>--}}
                                    {{--<div class="col-lg-10 col-md-10 col-sm-10 col-xs-12">--}}
                                        {{--<div class="nk-int-st">--}}
                                            {{--<input type="number" name="requested_quantity" id="requested_quantity" class="form-control input-md" placeholder="quantity" required>--}}
                                        {{--</div>--}}
                                    {{--</div>--}}
                                {{--</div>--}}
                            {{--</div>--}}
                        {{--</div>--}}

                        {{--<div class="form-example-int form-horizental">--}}
                            {{--<div class="form-group">--}}
                                {{--<div class="row">--}}
                                    {{--<div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">--}}
                                        {{--<label class="hrzn-fm ">Project Name</label>--}}
                                    {{--</div>--}}
                                    {{--<div class="col-lg-10 col-md-10 col-sm-10 col-xs-12">--}}
                                        {{--<div class="nk-int-st">--}}
                                            {{--<input type="text" name="project_name" id="project_name" class="form-control input-md" placeholder="name" required >--}}
                                        {{--</div>--}}
                                    {{--</div>--}}
                                {{--</div>--}}
                            {{--</div>--}}
                        {{--</div>--}}
                    {{--</div>--}}
                    {{--<div class="modal-footer">--}}
                        {{--<button onclick="addRequestedQty()" class="btn btn-default">Add Request</button>--}}
                        {{--<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>--}}
                    {{--</div>--}}
                {{--</form>--}}
            </div>
        </div>
    </div> <script src="{{asset('js/requestedGoods/main.js')}}"></script>

@endsection
