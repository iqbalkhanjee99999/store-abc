
function showFormItems(id) {
    window.location = '/reports/recivingItemsReports/'+id;
}

