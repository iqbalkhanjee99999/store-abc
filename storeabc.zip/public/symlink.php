<?php 
symlink('/home3/srtechme/shopProject/attachments','/home3/srtechme/public_html/storeabc/attachments');
?>