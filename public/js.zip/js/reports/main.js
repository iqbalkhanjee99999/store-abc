
function showFormItems(id) {
    window.location = '/reports/recivingItemsReports/'+id;
}

function showProjectFormItems(id) {
    window.location = '/reports/projectRecivingItemsReports/'+id;
}

function showProjectToolsFormItems(id) {
    window.location = '/reports/showProjectToolsFormItems/'+id;
}

