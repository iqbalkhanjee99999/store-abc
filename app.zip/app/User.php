<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

class User extends Authenticatable
{
//    use Notifiable;
//
//    /**
//     * The attributes that are mass assignable.
//     *
//     * @var array
//     */
//    protected $fillable = [
//        'name', 'email', 'password',
//    ];
//
//    /**
//     * The attributes that should be hidden for arrays.
//     *
//     * @var array
//     */
//    protected $hidden = [
//        'password', 'remember_token',
//    ];

    public function addUser($data){
        DB::table('users')
            ->insert([
                'name' => $data['name'],
                'email' => $data['email'],
                'phone_no' => $data['phone_no'],
                'address' => $data['address'],
                'password' => Hash::make('User123!')
            ]);
    }

    public function getAllUsers(){
       $data=  DB::table('users')
           ->where('user_type',1)
           ->orderBy('id','desc')
           ->get();
       return $data;
    }

    public function getUser($id){
        $data=  DB::table('users')
            ->where('id',$id)
            ->first();
        return $data;
    }

    public function updateUser($data){
        DB::table('users')
            ->where('id',$data['user_id'])
            ->update([
                'name' => $data['name'],
                'email' => $data['email'],
                'phone_no' => $data['phone_no'],
                'address' => $data['address'],
            ]);
    }

    public function resetPassword($id){
        DB::table('users')
            ->where('id',$id)
            ->update([
                'password' =>  Hash::make('User123!')
            ]);
    }

    public function getCountAllUsers(){
        $data = User::count();
        return $data;
    }

    public function deleteEngineer($id){
        DB::table('users')
            ->where('id',$id)
            ->delete();
    }

    public function getPassword($id){
        $data = DB::table('users')
            ->where('id',$id)
            ->select('password')
        ->first();
        return $data->password;
    }

    public function changePassword($new_password){
        DB::table('users')
            ->where('id',Auth::user()->id)
            ->update([
                'password' =>  Hash::make($new_password)
            ]);
    }
}
