<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class RequestedGoods extends Model
{
    public function addRequestedGoods($data){

        foreach($data['items'] as $k => $val){
            $category =  DB::table('category_items')
                ->where('id',$data['items'][$k])
                ->select('category_id','description')
                ->first();

            DB::table('request_goods')
                ->insert([
                    'category_id'   => $category->category_id,
                    'item_id'       => $data['items'][$k],
                    'user_id'       => Auth::user()->id,
                    'requested_qty' => $data['requested_qty'][$k],
                    'project_name'  => $data['project_name'],
                    'date'          => date('Y-m-d'),
                ]);

            DB::table('category_items')
                ->where('id',$data['items'][$k])
                ->decrement('quantity',$data['requested_qty'][$k]);
        }

    }

    public function getPendingRequests(){
        $data = DB::table('request_goods')
            ->join('category_items','request_goods.item_id','=','category_items.id')
            ->join('categories','request_goods.category_id','=','categories.id')
            ->join('users','request_goods.user_id','=','users.id')
            ->where('request_goods.proc_approval',0)
            ->orWhere('request_goods.store_approval',0)
            ->select(
                'request_goods.id as requested_goods_id',
                'request_goods.*',
                'categories.*',
                'category_items.*',
                'users.name'
            )
            ->get();
        return $data;
    }

    public function procurementApprove($id){
        DB::table('request_goods')
            ->where('id',$id)
            ->update([
                'proc_approval'   => 1,
            ]);
    }
    public function procurementReject($id){
        DB::table('request_goods')
            ->where('id',$id)
            ->update([
                'proc_approval'   => 2,
            ]);
    }

    public function storeManagerApprove($id){
        DB::table('request_goods')
            ->where('id',$id)
            ->update([
                'store_approval'   => 1,
            ]);
    }

    public function storeManagerReject($id){
        DB::table('request_goods')
            ->where('id',$id)
            ->update([
                'store_approval'   => 2,
            ]);
    }

    public function myOrders(){
        $data = DB::table('request_goods')
            ->join('category_items','request_goods.item_id','=','category_items.id')
            ->join('categories','request_goods.category_id','=','categories.id')
            ->join('users','request_goods.user_id','=','users.id')
            ->where('user_id',Auth::user()->id)
            ->select(
                'request_goods.id as requested_goods_id',
                'request_goods.*',
                'categories.*',
                'category_items.*',
                'users.name'
            )
            ->get();
        return $data;
    }

    public function totalRequested(){
        $data = DB::table('request_goods')
            ->sum('requested_qty');
        return $data;
    }

    public function getRequestedUserId($id){
        $data = DB::table('request_goods')
            ->where('id',$id)
            ->select('user_id')
            ->first();
        return $data->user_id;
    }

    public function updateQuantity($id){
        $data = DB::table('request_goods')
            ->where('id',$id)
            ->select('requested_qty','item_id')
            ->first();
        $quantity =  $data->requested_qty;
        $item_id =  $data->item_id;

        DB::table('category_items')
            ->where('id',$item_id)
            ->increment('quantity',$quantity);
    }
}
