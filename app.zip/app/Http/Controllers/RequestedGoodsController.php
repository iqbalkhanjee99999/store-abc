<?php

namespace App\Http\Controllers;

use App\Category;
use App\Notifications;
use App\RequestedGoods;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Notifications\Notification;
use Illuminate\Support\Facades\Auth;
class RequestedGoodsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function addRequest(){
        $category = new Category();
        $categories = $category->getAllCategories();

        if(Auth::user()->user_type == 1001 ||Auth::user()->user_type == 101 || Auth::user()->user_type == 1){
            return view('requestedGoods.addRequest')->with('categories',$categories);
        }
        else{
            return redirect('/home');
        }
    }

    public function getItemDetails($id){

        $category = new Category();
        $data = $category->getItemData($id);

        die(json_encode($data));
    }

    public function addRequestedGoods(Request $request){


        $data['requested_qty']      = $request->requested_qty;
        $data['project_name']       = $request->project_name;
        $data['items']              = $request->items;

        $requestedGoods = new RequestedGoods();
        $requestedGoods->addRequestedGoods($data);

        $noti['title'] = 'Goods Requested';
        $noti['description'] = 'Engineer Requested Goods. Please Take Required Action';
        $noti['link'] = 'requestedGoods/PendingRequests';


        $notification = new Notifications();
        $notification->procSendNotification($noti);

        return redirect()->back();
    }

    public function PendingRequests($id = 0){
        $goods = new RequestedGoods();
        $data = $goods->getPendingRequests();

        if($id > 0){
            $noti = new Notifications();
            $noti->changeStatusToRead($id);
        }
        if(Auth::user()->user_type == 1001 || Auth::user()->user_type == 101 || Auth::user()->user_type == 2){
            return view('requestedGoods.pendingRequests')->with('data',$data);
        }
        else{
            return redirect('/home');
        }
    }

    public function procurementApprove($id){

        $goods = new RequestedGoods();
        $goods->procurementApprove($id);

        $noti['title'] = 'Request Approved';
        $noti['description'] = 'Procurement Accepted Goods Request. Please Take Required Action';
        $noti['link'] = 'requestedGoods/PendingRequests';


        $notification = new Notifications();
        $notification->storeManagerSendNotification($noti);

        return redirect()->back();
    }

    public function procurementReject($id){
        $goods = new RequestedGoods();
        $goods->procurementReject($id);
        $goods->updateQuantity($id);
        $user_id = $goods->getRequestedUserId($id);

        $noti['title'] = 'Request Rejected';
        $noti['description'] = 'Rejected By Procurement Manager';
        $noti['link'] = 'requestedGoods/MyOrders';
        $noti['user_id'] = $user_id;

        $notification = new Notifications();
        $notification->engineerSendNotification($noti);

        return redirect()->back();
    }

    public function storeManagerReject($id){
        $goods = new RequestedGoods();
        $goods->storeManagerReject($id);
        $user_id = $goods->getRequestedUserId($id);
        $goods->updateQuantity($id);

        $noti['title'] = 'Request Rejected';
        $noti['description'] = 'Rejected By Store Manager';
        $noti['link'] = 'requestedGoods/MyOrders';
        $noti['user_id'] = $user_id;


        $notification = new Notifications();
        $notification->engineerSendNotification($noti);

        return redirect()->back();
    }

    public function storeManagerApprove($id){
        $goods = new RequestedGoods();
        $goods->storeManagerApprove($id);

        $user = new RequestedGoods();
        $user_id = $user->getRequestedUserId($id);

        $noti['title'] = 'Request Approved';
        $noti['description'] = 'Your Request is Approved';
        $noti['link'] = 'requestedGoods/MyOrders';
        $noti['user_id'] = $user_id;

        $notification = new Notifications();
        $notification->engineerSendNotification($noti);

        return redirect()->back();
    }

    public function MyOrders($id = 0){
        $goods = new RequestedGoods();
        $data = $goods->myOrders();

        if($id > 0){
            $noti = new Notifications();
            $noti->changeStatusToRead($id);
        }

        return view('requestedGoods.myOrders')->with('data',$data);
    }
}
