<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Category extends Model
{
    public function getAllCategories(){
        $data = DB::table('categories')
            ->select('id','title','description')
            ->orderBy('id','desc')
            ->get();
        return $data;
    }

    public function getLastFiveCategories(){
        $data = DB::table('categories')
            ->select('id','title','description')
            ->orderBy('id','desc')
            ->limit(5)
            ->get();
        return $data;
    }

    public function addCategory($data){
        DB::table('categories')
            ->insert([
                'title' => $data['title'],
                'description' => $data['description']
            ]);
    }

    public function updateCategory($data){
        DB::table('categories')
            ->where('id',$data['item_id'])
            ->update([
                'title' => $data['title'],
                'description' => $data['description']
            ]);
    }

    public function getCategoryDetails($id){
        $data = DB::table('categories')
            ->where('id',$id)
            ->select('id','title','description')
            ->first();
        return $data;
    }

    public function getCategoryData($id){
        $data = DB::table('categories')
            ->select('id','title')
            ->where('id',$id)
            ->first();
        return $data;
    }

    public function getCategoryItems($id){
        $data = DB::table('category_items')
            ->where('category_id',$id)
            ->orderBy('id','desc')
            ->get();
        return $data;
    }

    public function getLastSevenItems(){
        $data = DB::table('category_items')
            ->orderBy('id','desc')
            ->limit(7)
            ->get();
        return $data;
    }

    public function addCategoryItem($data){
        DB::table('category_items')
            ->insert([
                'category_id'   => $data['category_id'],
                'description'   => $data['description'],
                'model_no'      => $data['model_no'],
                'brand_name'    => $data['brand_name'],
                'photo'         => $data['photo'],
                'zone_no'       => $data['zone_no'],
                'column_no'     => $data['column_no'],
                'shelf_no'      => $data['shelf_no'],
                'carton_no'     => $data['carton_no'],
            ]);
    }

    public function updateCategoryItem($data){
        DB::table('category_items')
            ->where('id',$data['item_id'])
            ->update([
                'category_id'   => $data['category_id'],
                'description'   => $data['description'],
                'model_no'      => $data['model_no'],
                'brand_name'    => $data['brand_name'],
                'photo'         => $data['photo'],
                'zone_no'       => $data['zone_no'],
                'shelf_no'      => $data['shelf_no'],
                'carton_no'     => $data['carton_no'],
            ]);
    }

    public function getItemCategory($id){
        $data =  DB::table('category_items')
            ->where('id',$id)
            ->select('category_id','description')
            ->first();
        return $data;
    }

    public function checkCategory($id){

        $data =  DB::table('category_items')
            ->where('category_id',$id)
            ->count();
        return $data;
    }

    public function checkItem($id){

        $data =  DB::table('form_items')
            ->where('item_id',$id)
            ->count();
        return $data;
    }

    public function deleteCategory($id){

        DB::table('categories')
            ->where('id',$id)
            ->delete();
    }

    public function getItemData($item_id){
       $data =  DB::table('category_items')
            ->where('id',$item_id)
            ->first();
        return $data;
    }

    public function getAllItemsCount(){
        $data =  DB::table('category_items')->count();
        return $data;
    }

    public function deleteItem($id){

        DB::table('category_items')
            ->where('id',$id)
            ->delete();
    }
}
