<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

////////////////////Categories/////////////////////////////////
Route::get('/categories/showAll', 'CategoriesController@showAll');
Route::get('/categories/addNew/{id?}', 'CategoriesController@addNew');
Route::get('/categories/deleteCategory/{id}', 'CategoriesController@deleteCategory');
Route::post('/categories/saveCategory', 'CategoriesController@saveCategory');
Route::post('/categories/addCategoryItem', 'CategoriesController@addCategoryItem');
Route::get('/categories/categoryItems/{id}', 'CategoriesController@categoryItems');
Route::get('/categories/items/newItem/{id}/{item_id?}', 'CategoriesController@newItem');
Route::get('/categories/deleteItem/{id}', 'CategoriesController@deleteItem');

////////////////////Reciving Goods/////////////////////////////////
Route::get('/recivingGoods', 'RecivingGoodsController@recivingGoods');
Route::get('/recivingGoods/getCategoryItems/{id}', 'RecivingGoodsController@getCategoryItems');
Route::post('/recivingGoods/getItemDetails', 'RecivingGoodsController@getItemDetails');
Route::post('/recivingGoods/addRecivingGoodsData', 'RecivingGoodsController@addRecivingGoodsData');
Route::get('/recivingGoods/getItembyCat/{id}', 'RecivingGoodsController@getItembyCat');


////////////////users///////////////////////////
Route::get('users/allUsers', 'UserController@allUsers');
Route::get('users/addEngineer/{id?}', 'UserController@addEngineer');
Route::get('users/deleteEngineer/{id}', 'UserController@deleteEngineer');
Route::get('users/changePassword', 'UserController@changePassword');
Route::post('users/updatePassword', 'UserController@updatePassword');
Route::post('users/saveEngineer', 'UserController@saveEngineer');
Route::get('users/resetPassword/{id}', 'UserController@resetPassword');

//////////////////////Requested Goods//////////////////////
Route::get('requestedGoods/addRequest', 'RequestedGoodsController@addRequest');
Route::get('requestedGoods/getItemDetails/{id}', 'RequestedGoodsController@getItemDetails');
Route::post('requestedGoods/addRequestedGoods', 'RequestedGoodsController@addRequestedGoods');
Route::get('requestedGoods/PendingRequests/{id?}', 'RequestedGoodsController@PendingRequests');
Route::get('requestedGoods/procurementApprove/{id}', 'RequestedGoodsController@procurementApprove');
Route::get('requestedGoods/procurementReject/{id}', 'RequestedGoodsController@procurementReject');
Route::get('requestedGoods/storeManagerReject/{id}', 'RequestedGoodsController@storeManagerReject');
Route::get('requestedGoods/storeManagerApprove/{id}', 'RequestedGoodsController@storeManagerApprove');
Route::get('requestedGoods/MyOrders/{id?}', 'RequestedGoodsController@MyOrders');

/////////////////////Reports////////////////////////////////////

Route::get('reports/requestedItemsReports', 'ReportsController@requestedItemsReports');
Route::get('reports/recivingItemsReports/{id}', 'ReportsController@recivingItemsReports');
Route::get('reports/inventoryList', 'ReportsController@inventoryList');
Route::get('reports/recivingItems', 'ReportsController@recivingItems');
Route::get('reports/exportToExcel', 'ReportsController@exportToExcel');
Route::get('reports/exportToExcelRequested', 'ReportsController@exportToExcelRequested');
Route::get('reports/exportToExcelRecieved', 'ReportsController@exportToExcelRecieved');

//////////////////Notificaitons////////////////////////////
Route::get('notifications/viewAll', 'NotificationController@viewAll');
Route::get('notifications/markAllAsRead', 'NotificationController@markAllAsRead');

